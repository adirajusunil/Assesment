package com.ch.croptohome.reposervice;

import com.ch.croptohome.model.Employee;

public interface IEmployeeService {
public void saveEmployeeDtls(Employee employee);
}
